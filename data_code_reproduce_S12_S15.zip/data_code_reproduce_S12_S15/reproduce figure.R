

library(ggplot2)
library(dplyr)
library(tidyr)
library(gridExtra)
library(grid)  
library(deSolve)
library(patchwork)   # optional, much cleaner for arranging plots
library(ggsci)
library(purrr)

# Load data # replace with S12 data
line_df_all <- readRDS("lineplot_figS15.rds")
bar_df_all  <- readRDS("barplot_figS15.rds")

regions <- sort(unique(as.numeric(line_df_all$region_list)))

region_states <- c(
  "1"  = "CT, ME, MA, NH, RI, VT",
  "2"  = "NJ, NY, PR, VI",
  "3"  = "DE, DC, MD, PA, VA, WV",
  "4"  = "AL, FL, GA, KY, MS, NC, SC, TN",
  "5"  = "IL, IN, MI, MN, OH, WI",
  "6"  = "AR, LA, NM, OK, TX",
  "7"  = "IA, KS, MO, NE",
  "8"  = "CO, MT, ND, SD, UT, WY",
  "9"  = "AZ, CA, HI, NV",
  "10" = "AK, ID, OR, WA"
)

plot_list <- list()

mypal <- pal_npg("nrc", alpha = .7)(9)

for (region in regions) {
  
  line_df <- line_df_all %>%
    filter(region_list == as.character(region))
  
  bar_df <- bar_df_all %>%
    filter(region_list == as.character(region))
  
  # Panel A: Line plot
  p1 <- ggplot() +
    geom_line(
      data = line_df,
      aes(x = as.Date(Date), y = Count, color = Type),
      size = 1
    ) +
    scale_color_manual(
      values = c(
        "Raw" = "grey",
        "Rescaled" = "black",
        "Model fit" = "red",
        "RSV" = "transparent"
      )
    ) +
    labs(x = "", y = "Number of positive tests", color = NULL) +
    theme_minimal(base_size = 13) +
    theme(
      axis.title.x = element_text(size = 16),
      axis.title.y = element_text(size = 16),
      axis.text.x = element_text(size = 16),
      axis.text.y = element_text(size = 16),
      legend.position = "top",
      legend.text = element_text(size = 16),
      legend.key.size = unit(1.2, "lines"),
      plot.margin = margin(5.5, 20, 5.5, 5.5)  # top, right, bottom, left (pt)
    )
  
  # Panel B: Bar plot
  p2 <- ggplot(bar_df, aes(x = Age, y = Proportion, fill = Source)) +
    geom_bar(
      stat = "identity",
      position = position_dodge(width = 0.8),
      width = 0.7
    ) +
    scale_fill_manual(
      values = c("Model fit" = mypal[1], "Data" = mypal[4])
    ) +
    labs(y = "Proportion", x = NULL, fill = NULL) +
    theme_minimal(base_size = 13) +
    theme(
      axis.title.x = element_text(size = 16),
      axis.title.y = element_text(size = 16),
      axis.text.x = element_text(size = 13),
      axis.text.y = element_text(size = 13),
      legend.position = "top",
      legend.text = element_text(size = 16),
      legend.key.size = unit(1.2, "lines")
    )
  
  # Region title
  title <- textGrob(
    paste0("Region ", region, ": ",
           region_states[as.character(region)]),
    gp = gpar(fontsize = 15, fontface = "bold")
  )
  
  # Combine two panels
  plot_combined <- arrangeGrob(
    title,
    arrangeGrob(p1, p2, ncol = 2),
    heights = c(0.1, 1)
  )
  
  plot_list[[as.character(region)]] <- plot_combined
}

# Reproduce Figure 3B
 do.call(
  grid.arrange,
  c(plot_list, nrow = 5, ncol = 2)
)
